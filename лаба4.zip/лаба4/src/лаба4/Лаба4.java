/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ����4;
import ����4.newpackage.*;
/**
 *
 * @author ���������
 */
public class ����4 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Computer comp = new Computer(true, "HP");
        Gadget phone = new Gadget(true, "Iphone");
        PassengerCar car = new PassengerCar(true, "Porshe");
        Truck truck = new Truck(true, "VOLVO");
        
        Client cl1 = new Client("Vlad");
        Client cl2 = new Client("Oleg");
        
        Service<Technique> serviceTr = new ServiceTransport();
        Service<Technique> serviceGadget = new ServiceGadgets();
        
        serviceTr.recording(cl1, comp);
        comp.breakDown();
        comp.fixing();
        serviceTr.history();
        
        
        serviceGadget.recording(cl2, truck);
        truck.breakDown();
        truck.fixing();
        serviceGadget.history();
        
    }
    
}
