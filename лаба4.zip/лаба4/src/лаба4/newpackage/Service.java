/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package ����4.newpackage;

/**
 *
 * @author ���������
 */
public interface Service<T extends Technique> {
    void fixing(T technique);
    void history();
    void recording(Client client, T technique);
}
