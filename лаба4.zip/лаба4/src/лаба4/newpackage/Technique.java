/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����4.newpackage;

/**
 *
 * @author ���������
 */
public abstract class Technique {
    private boolean status;
    private String name;
    
    public Technique(boolean status, String name){
        this. status = status;
        this.name = name;
    }
    
    public String getName(){
        return name;
    }
    public boolean isWork(){
        return status;
    }
    public void breakDown(){
        this.status = false;
        System.out.println(name + " ����������");
    }
    public void fixing(){
        this.status = true;
        System.out.println(name + " ��������");
    }
    public abstract void info();
}
