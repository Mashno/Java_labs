/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����5;

/**
 *
 * @author ���������
 */

public class Product {
    private String name;
    private double protein;
    private double fat;
    private double carbon;
    
    public Product(String name, double protein, double fat, double carbon){
        this.name = name;
        this.protein = protein;
        this.carbon = carbon;
        this.fat = fat;
    }
    
    public String getName(){
        return name;
    }
    public double getProtein(){
        return protein;
    }
    public double getCarbon(){
        return carbon;
    }
    public double getFat(){
        return fat;
    }
    
    public double Callories(double gramms){
        return (protein*4.1 + carbon*4.1 + fat*9.29)*gramms/100;
    }
    
}
