/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����5;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
/**
 *
 * @author ���������
 */
public class FirstMenu extends JFrame implements ActionListener{
    
    public ArrayList<Citizen> citizens;
    public ArrayList<Product> products;
    
    JButton btn1, btn2, btn3;
    public FirstMenu(ArrayList<Citizen> citizens, ArrayList<Product> products){
        super("������ ����");
        this.citizens = citizens;
        this.products = products;
//        citizens = new ArrayList<>();
//        Constructor.DefineCit(citizens);
//        
//        products = new ArrayList<>();
//        Constructor.Food(products);
        
        
        JPanel panel = new JPanel();
        getContentPane().add(panel);
        btn1 = new JButton("���������� �������� ��� �������� ������������");
        btn2 = new JButton("�������� � ���������� ��������");
        btn3 = new JButton("�����");
        setLayout(new FlowLayout(FlowLayout.CENTER, 10,10));
        btn1.setActionCommand("People");
        btn2.setActionCommand("Callories");
        btn3.setActionCommand("Exit");
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        btn3.addActionListener(this);
        
        add(btn1);
        add(btn2);
        add(btn3);
        
        pack();
        setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String str = e.getActionCommand();
        if("People".equals(str)){
            dispose();
            AddOrShowPerson aosp = new AddOrShowPerson( products, citizens);
        }
        
        if("Callories".equals(str)){
            dispose();
            new CleanOrAddCalorries( products, citizens);
        }
        
        if("Exit".equals(str)){
            System.exit(0);
        }
    }
}
