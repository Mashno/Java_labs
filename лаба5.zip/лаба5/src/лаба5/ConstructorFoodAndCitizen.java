/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����5;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 *
 * @author ���������
 */
public class ConstructorFoodAndCitizen {
    public static void DefineCit(ArrayList<Citizen> citizens){
        citizens.add(new Citizen("Vlad", 184.0, 95.0, 20,1,1000.0));
        citizens.get(0).setKoef(3);
        citizens.add(new Citizen("George", 167.0, 50.0, 40,1,2000.0));
        citizens.add(new Citizen("Alla", 185.0, 60.0, 35,0,1030.0));
        citizens.add(new Citizen("Lena", 174.0, 55.0, 15,0,1780.0));
       for(int i = 0; i<4; i++){
           citizens.get(i).setKoef(i);
       }
        
    }
    
    public static void Food(ArrayList<Product> products){
        String filePath = "empty_file.txt"; // �� ������ �������� ��� ����� � ����

        File file = new File(filePath);
        
        InputStream stream = null;
        InputStreamReader isr = null;
        System.out.println(file.exists());
        try {
            stream = new FileInputStream(file);
            isr = new InputStreamReader(stream, "UTF-8");
            int length = stream.available();
            char[] data = new char[length];
            isr.read(data);
            String text = new String(data);
            ArrayList<Product> lineWords = new ArrayList<>();
            String[] lines = text.split("\n");
            for(String line: lines){
                String[] aspect = line.split(";");
                products.add(new Product(aspect[0], Double.parseDouble(aspect[1]), Double.parseDouble(aspect[2]),Double.parseDouble(aspect[3])));
                
            }
        } catch (FileNotFoundException ex) {
            ex.printStackTrace();
            products.add(new Product("������", 4,2,4));
            products.add(new Product("������", 3,23,23));
            products.add(new Product("�������", 2,23,42));
            products.add(new Product("����", 32,2,2));
            products.add(new Product("������� ����", 32,23,23));
        } catch (IOException ex) {
            ex.printStackTrace();
        } finally {
            try {
                stream.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
            try {
                isr.close();
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }
}
