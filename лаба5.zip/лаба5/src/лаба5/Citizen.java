/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����5;

/**
 *
 * @author ���������
 */
public class Citizen {
    private String name;
    private double growth;
    private double weight;
    private int age;
    private int sex;//0 - �������, 1 - �������
    private double koef;
    private double callories;
    
    public Citizen(String name, double growth, double weight, int age, int sex, double callories){
        this.name = name;
        this.growth = growth;
        this.weight = weight;
        this.age = age;
        this.sex = sex;
        this.callories = callories;
    }
    
    public String getName(){
       return name; 
    }
    public double getGrowth(){
       return growth; 
    }
    public double getWeight(){
       return weight; 
    }
    public int getAge(){
       return age; 
    }
    public int getSex(){
       return sex; 
    }
    public double getKoef(){
       return koef; 
    }
    public double getCallories(){
       return callories; 
    }
    
    public void setName(String name){
        this.name = name;
    }
    public void setGrowth(double growth){
        this.growth = growth;
    }
    public void setWeight(double weight){
        this.weight = weight;
    }
    public void setAge(int age){
        this.age = age;
    }
    public void setSex(int sex){
        this.sex = sex;
    }
    public void setKoef(int level){
        switch(level){
            case 0:
                this.koef = 1.2;
                break;
            case 1:
                this.koef = 1.38;
                break;
            case 2:
                this.koef = 1.46;
                break;
            case 3:
                this.koef = 1.55;
                break;
            case 4:
                this.koef = 1.64;
                break;
            case 5:
                this.koef = 1.73;
                break;
            case 6:
                this.koef = 1.9;
                break;
        }
    }
    public void setCallories(double cal){
        this.callories = this.callories + cal;
    }
    
    public double DCIMethod(){
        if(sex == 1){
            return (weight*10 + growth*6.25 - age*5 +5)*koef;
        } else{
            return (weight*10 + growth*6.25 - age*5 -161)*koef;
        }      
    }
    
    public void Decision(){
        if(callories > DCIMethod()){
            System.out.println("������� " + callories +", " + "DCI - " + DCIMethod() +". " + name + ", �� ����������((");
        } else {
            System.out.println("������� " + callories +", " + "DCI - " + DCIMethod() +". " + name + ", �� ��������))");
        }
    }
    
    public String Decision(String a){
        if(callories > DCIMethod()){
            return "������� " + callories +", " + "DCI - " + DCIMethod() +". " + name + ", �� ����������((";
        } else {
            return "������� " + callories +", " + "DCI - " + DCIMethod() +". " + name + ", �� ��������))";
        }
    }
    
    public void NewDay(){
        this.callories = 0;
    }
    
    
}
