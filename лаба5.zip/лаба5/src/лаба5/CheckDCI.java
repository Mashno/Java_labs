/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����5;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author ���������
 */
public class CheckDCI extends JFrame implements ItemListener, ActionListener{
    JComboBox people;
    public ArrayList<Citizen> citizens;
    public ArrayList<Product> products;
    JLabel answer;
    String[] names;
    JButton exit;
    
    public CheckDCI(String str,ArrayList<Citizen> citizens, ArrayList<Product> products){
        super(str);
        this.citizens = citizens;
        this.products = products;
        
        String[] names = citizens.stream().map(Citizen::getName).toArray(String[]::new);
        
        people = new JComboBox(names);
        answer = new JLabel("�������� �������� �� ������");
        exit = new JButton("�����");
        
        exit.setActionCommand("Exit");
        exit.addActionListener(this);
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(people, BorderLayout.NORTH);
        panel.add(answer, BorderLayout.CENTER);
        panel.add(exit, BorderLayout.SOUTH);
        
        getContentPane().add(panel);
        people.addItemListener(this);
        people.setBackground(Color.LIGHT_GRAY);
        people.setForeground(Color.black);
        panel.setBackground(Color.black);
        answer.setForeground(Color.white);
        
       
        setSize(500, 200);
        setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    
    @Override
    public void itemStateChanged(ItemEvent e){
        if(e.getStateChange() == ItemEvent.SELECTED){
            String name = (String)e.getItem();
            int index =people.getSelectedIndex();
            String txt = citizens.get(index).Decision("for gui");
            answer.setText(txt);
        } 
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String str = e.getActionCommand();
        if("Exit".equals(str)){
            dispose();
            new AddOrShowPerson( products, citizens);
        } 
    }
}
