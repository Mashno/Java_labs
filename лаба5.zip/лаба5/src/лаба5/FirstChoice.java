/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ����5;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;

/**
 *
 * @author ���������
 */
public class FirstChoice extends JFrame implements ActionListener{
    JButton btn1, btn2;
    public ArrayList<Product> products;
    public ArrayList<Citizen> citizens;
    public FirstChoice(String title,ArrayList<Product> products,ArrayList<Citizen> citizens){
        super(title);
        this.products=products;
        this.citizens=citizens;
        JPanel panel = new JPanel();
        getContentPane().add(panel);
        btn1 = new JButton("�������� � GUI");
        btn2 = new JButton("�������� � ��������� ������");
        setLayout(new FlowLayout(FlowLayout.CENTER, 10,10));
        btn1.setActionCommand("GUI");
        btn2.setActionCommand("Console");
        btn1.addActionListener(this);
        btn2.addActionListener(this);
        
        add(btn1);
        add(btn2);
        
        pack();
        setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        String str = e.getActionCommand();
        if("GUI".equals(str)){
            dispose();
            FirstMenu fm = new FirstMenu(citizens, products);
        }
        
        if("Console".equals(str)){
            dispose();
            Programme pr = new Programme(citizens, products);
            pr.WorkProgramme();
            
        }
    }
    
}
