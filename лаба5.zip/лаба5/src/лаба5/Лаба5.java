/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ����5;

import java.util.ArrayList;

/**
 *
 * @author ���������
 */
public class ����5 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        ArrayList<Citizen> citizens = new ArrayList<>();
        ConstructorFoodAndCitizen.DefineCit(citizens);
        
        ArrayList<Product> products = new ArrayList<>();
        ConstructorFoodAndCitizen.Food(products);
        
        FirstChoice fc = new FirstChoice("1 �����", products, citizens);
    }
    
}
